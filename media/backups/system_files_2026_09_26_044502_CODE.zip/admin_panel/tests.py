import json
from datetime import date, timedelta
from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from openpyxl.utils.datetime import to_excel

from admin_panel import views
from cashier.models import Cheque, FundCluster, Report, Supplier


class RegistrySheetTests(TestCase):
	def setUp(self):
		self.admin = User.objects.create_superuser(username='admin', email='admin@example.com', password='pass12345')
		self.supplier = Supplier.objects.create(
			account_name='Original Name',
			account_number='001',
			address='Old Address',
			tin='TIN-1',
			status='active',
			created_by=self.admin,
			raw_import={
				'sheet': 'Registry',
				'row_number': 1,
				'headers': ['account_name', 'account_number', 'address', 'tin', 'status'],
				'columns': ['account_name', 'account_number', 'address', 'tin', 'status'],
				'values': ['Original Name', '001', 'Old Address', 'TIN-1', 'active'],
				'cells': [
					{'header': 'account_name', 'value': 'Original Name'},
					{'header': 'account_number', 'value': '001'},
					{'header': 'address', 'value': 'Old Address'},
					{'header': 'tin', 'value': 'TIN-1'},
					{'header': 'status', 'value': 'active'},
				],
				'data': {
					'account_name': 'Original Name',
					'account_number': '001',
					'address': 'Old Address',
					'tin': 'TIN-1',
					'status': 'active',
				},
			},
		)
		self.cashier = User.objects.create_user(username='cashier', email='cashier@example.com', password='pass12345')

	def test_registry_sheet_save_updates_supplier(self):
		self.client.force_login(self.admin)

		payload = {
			'sheet_name': 'Registry',
			'headers': ['account_name', 'account_number', 'address', 'tin', 'status'],
			'rows': [
				{
					'supplier_id': self.supplier.pk,
					'cells': ['Updated Name', '999', 'New Address', 'TIN-9', 'inactive'],
				}
			],
		}

		response = self.client.post(
			reverse('registry'),
			data={
				'action': 'save',
				'sheet_payload': json.dumps(payload),
			},
		)

		self.assertEqual(response.status_code, 200)
		self.supplier.refresh_from_db()
		self.assertEqual(self.supplier.account_name, 'Updated Name')
		self.assertEqual(self.supplier.account_number, '999')
		self.assertEqual(self.supplier.address, 'New Address')
		self.assertEqual(self.supplier.tin, 'TIN-9')
		self.assertEqual(self.supplier.status, 'inactive')
		self.assertEqual(self.supplier.raw_import['cells'][0]['value'], 'Updated Name')

	def test_cashier_supplier_defaults_follow_own_flow(self):
		Supplier.objects.create(
			account_name='Admin Flow Supplier',
			created_by=self.admin,
			series_month='99',
			series_day='12',
		)

		self.client.force_login(self.cashier)
		response = self.client.get(reverse('suppliers'))

		self.assertEqual(response.status_code, 200)
		self.assertEqual(response.context['auto_supplier_series_month'], '1')
		self.assertEqual(response.context['auto_supplier_series_day'], '1')

	def test_cashier_or_number_uses_highest_existing_value(self):
		Supplier.objects.create(
			account_name='Older OR Supplier',
			created_by=self.cashier,
			or_number='1-32319',
		)
		Supplier.objects.create(
			account_name='Newer OR Supplier',
			created_by=self.cashier,
			or_number='1-54127',
		)
		Supplier.objects.create(
			account_name='Admin OR Supplier',
			created_by=self.admin,
			or_number='1-99999',
		)

		self.client.force_login(self.cashier)
		response = self.client.get(reverse('suppliers'))

		self.assertEqual(response.status_code, 200)
		self.assertEqual(response.context['auto_supplier_defaults']['or_number'], '1-54128')

	def test_past_dated_supplier_is_labeled_old_or(self):
		old_supplier = Supplier.objects.create(
			account_name='Old Date Supplier',
			created_by=self.cashier,
			mr='2016-jun-30',
			mr_or='2016-jun-30',
			raw_import={
				'data': {
					'date': '2016-06-30',
					'mr': '2016-jun-30',
				},
			},
			or_number='1-10001',
		)
		current_supplier = Supplier.objects.create(
			account_name='Current Date Supplier',
			created_by=self.cashier,
			date=date.today(),
			or_number='1-10002',
		)

		self.client.force_login(self.cashier)
		response = self.client.get(reverse('suppliers'))

		self.assertEqual(response.status_code, 200)
		page_suppliers = list(response.context['supplier_list'])
		self.assertTrue(any(s.pk == old_supplier.pk and s.is_old_or for s in page_suppliers))
		self.assertTrue(any(s.pk == current_supplier.pk and not s.is_old_or for s in page_suppliers))

	def test_supplier_defaults_use_current_flow_values(self):
		current_supplier = Supplier.objects.create(
			account_name='Current Flow Supplier',
			created_by=self.cashier,
			date=date.today(),
			mr_or='2026-may-31',
			mr='2026-may-31',
			code_line='NEW-LINE',
			code_noc='NEW-NOC',
			nature_of_collections='New Nature',
			raw_import={
				'data': {
					'date': date.today().isoformat(),
					'mr': '2026-may-31',
				},
			},
		)
		old_supplier = Supplier.objects.create(
			account_name='Old Flow Supplier',
			created_by=self.cashier,
			mr_or='2016-jun-30',
			mr='2016-jun-30',
			code_line='OLD-LINE',
			code_noc='OLD-NOC',
			nature_of_collections='Old Nature',
			raw_import={
				'data': {
					'date': '2016-06-30',
					'mr': '2016-jun-30',
				},
			},
		)
		Supplier.objects.filter(pk=old_supplier.pk).update(created_at=timezone.now())

		self.client.force_login(self.cashier)
		response = self.client.get(reverse('suppliers'))

		self.assertEqual(response.status_code, 200)
		self.assertEqual(response.context['auto_supplier_defaults']['mr_or'], '2026-may-32')
		self.assertEqual(response.context['auto_supplier_defaults']['code_line'], 'NEW-LINE-1')
		self.assertEqual(response.context['auto_supplier_defaults']['code_noc'], 'NEW-NOC-1')

	def test_supplier_import_creates_new_rows_for_duplicate_payee(self):
		rows = [
			{
				'PAYEE': 'Shared Payee',
				'OR NUMBER': '1-10001',
				'MR OR': '2026-may-31',
				'MR': '2026-may-31',
				'CODE OR': '1-1',
				'CODE OR 2': '1-1-1',
				'SERIES/MONTH': '1',
				'DATE': '2026-05-31',
				'SERIES/DAY': '1',
				'CODE LINE': 'LINE-1',
				'LINE': '1',
				'CODE NOC': 'NOC-1',
				'NATURE OF COLLECTIONS': 'Nature 1',
				'AMOUNT': '100',
				'REMARKS': 'First',
			},
			{
				'PAYEE': 'Shared Payee',
				'OR NUMBER': '1-10002',
				'MR OR': '2026-may-31',
				'MR': '2026-may-31',
				'CODE OR': '1-1',
				'CODE OR 2': '1-1-2',
				'SERIES/MONTH': '1',
				'DATE': '2026-05-31',
				'SERIES/DAY': '2',
				'CODE LINE': 'LINE-2',
				'LINE': '2',
				'CODE NOC': 'NOC-2',
				'NATURE OF COLLECTIONS': 'Nature 2',
				'AMOUNT': '200',
				'REMARKS': 'Second',
			},
		]

		count, _ = views._do_import('suppliers', rows, self.cashier)

		self.assertEqual(count, 2)
		self.assertEqual(Supplier.objects.filter(account_name='Shared Payee').count(), 2)

	def test_supplier_import_blocks_exact_duplicate_in_system(self):
		Supplier.objects.create(
			account_name='Blocked Payee',
			created_by=self.cashier,
			account_number='1-80001',
			mr_or='2026-may-31',
			mr='2026-may-31',
			date=date(2026, 5, 31),
			or_number='1-80001',
			code_line='LINE-Z',
			code_noc='NOC-Z',
		)
		rows = [
			{
				'PAYEE': 'Blocked Payee',
				'OR NUMBER': '1-80001',
				'MR OR': '2026-may-31',
				'MR': '2026-may-31',
				'CODE OR': '1-8',
				'CODE OR 2': '1-8-1',
				'SERIES/MONTH': '8',
				'DATE': '2026-05-31',
				'SERIES/DAY': '1',
				'CODE LINE': 'LINE-Z2',
				'LINE': 'Z2',
				'CODE NOC': 'NOC-Z2',
				'NATURE OF COLLECTIONS': 'Nature Z2',
				'AMOUNT': '500',
				'REMARKS': 'Duplicate row',
			},
		]

		count, _ = views._do_import('suppliers', rows, self.cashier)

		self.assertEqual(count, 0)
		self.assertEqual(Supplier.objects.filter(account_name='Blocked Payee').count(), 1)
		supplier = Supplier.objects.get(account_name='Blocked Payee')
		self.assertEqual(supplier.code_line, 'LINE-Z')
		self.assertEqual(supplier.code_noc, 'NOC-Z')
		self.assertEqual(supplier.amount, Decimal('0.00'))

	def test_supplier_import_merges_only_when_all_keys_match(self):
		rows = [
			{
				'PAYEE': 'Merge Payee',
				'OR NUMBER': '1-90001',
				'MR OR': '2026-may-31',
				'MR': '2026-may-31',
				'CODE OR': '1-9',
				'CODE OR 2': '1-9-1',
				'SERIES/MONTH': '9',
				'DATE': '2026-05-31',
				'SERIES/DAY': '1',
				'CODE LINE': 'LINE-A',
				'LINE': 'A',
				'CODE NOC': 'NOC-A',
				'NATURE OF COLLECTIONS': 'Nature A',
				'AMOUNT': '100',
				'REMARKS': 'First',
			},
			{
				'PAYEE': 'Merge Payee',
				'OR NUMBER': '1-90001',
				'MR OR': '2026-may-31',
				'MR': '2026-may-31',
				'CODE OR': '1-9',
				'CODE OR 2': '1-9-1',
				'SERIES/MONTH': '9',
				'DATE': '2026-05-31',
				'SERIES/DAY': '1',
				'CODE LINE': 'LINE-B',
				'LINE': 'B',
				'CODE NOC': 'NOC-B',
				'NATURE OF COLLECTIONS': 'Nature B',
				'AMOUNT': '250',
				'REMARKS': 'Second',
			},
		]

		count, _ = views._do_import('suppliers', rows, self.cashier)

		self.assertEqual(count, 1)
		self.assertEqual(Supplier.objects.filter(account_name='Merge Payee').count(), 1)
		supplier = Supplier.objects.get(account_name='Merge Payee')
		self.assertEqual(supplier.code_line, 'LINE-A')
		self.assertEqual(supplier.code_noc, 'NOC-A')
		self.assertEqual(supplier.amount, Decimal('100.00'))

	def test_supplier_import_parses_non_iso_dates(self):
		rows = [
			{
				'PAYEE': 'Date Format Supplier',
				'OR NUMBER': '1-20001',
				'MR OR': '2026-may-31',
				'MR': '2026-may-31',
				'CODE OR': '1-2',
				'CODE OR 2': '1-2-1',
				'SERIES/MONTH': '2',
				'DATE': 'May 29, 2026',
				'SERIES/DAY': '1',
				'CODE LINE': 'LINE-3',
				'LINE': '3',
				'CODE NOC': 'NOC-3',
				'NATURE OF COLLECTIONS': 'Nature 3',
				'AMOUNT': '300',
				'REMARKS': 'Date test',
			},
		]

		views._do_import('suppliers', rows, self.cashier)

		supplier = Supplier.objects.get(account_name='Date Format Supplier')
		self.assertEqual(supplier.date, date(2026, 5, 29))

	def test_supplier_import_parses_excel_serial_dates(self):
		rows = [
			{
				'PAYEE': 'Serial Date Supplier',
				'OR NUMBER': '1-30001',
				'MR OR': '2026-may-31',
				'MR': '2026-may-31',
				'CODE OR': '1-3',
				'CODE OR 2': '1-3-1',
				'SERIES/MONTH': '3',
				'DATE': to_excel(date(2026, 5, 29)),
				'SERIES/DAY': '1',
				'CODE LINE': 'LINE-4',
				'LINE': '4',
				'CODE NOC': 'NOC-4',
				'NATURE OF COLLECTIONS': 'Nature 4',
				'AMOUNT': '400',
				'REMARKS': 'Serial date test',
			},
		]

		views._do_import('suppliers', rows, self.cashier)

		supplier = Supplier.objects.get(account_name='Serial Date Supplier')
		self.assertEqual(supplier.date, date(2026, 5, 29))

		self.client.force_login(self.cashier)
		response = self.client.get(reverse('suppliers'))
		self.assertContains(response, 'May 29, 2026')

	def test_supplier_table_uses_mr_when_date_is_blank(self):
		Supplier.objects.create(
			account_name='MR Date Supplier',
			created_by=self.cashier,
			mr='2026-MAY-19',
			mr_or='2026-MAY-19',
			date=None,
			or_number='1-40001',
		)

		self.client.force_login(self.cashier)
		response = self.client.get(reverse('suppliers'))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'May 19, 2026')

	def test_cheque_summary_snapshot_filters_selected_fund_cluster(self):
		fund_one = FundCluster.objects.create(
			code='FC-001',
			name='Fund One',
			bank_name='Bank A',
			account_number='111-222',
		)
		fund_two = FundCluster.objects.create(
			code='FC-002',
			name='Fund Two',
			bank_name='Bank B',
			account_number='333-444',
		)
		supplier = Supplier.objects.create(account_name='Cheque Supplier', created_by=self.cashier)
		Cheque.objects.create(
			cheque_number='000001',
			payee=supplier,
			payee_name='Cheque Supplier',
			fund_cluster=fund_one,
			amount=Decimal('100.00'),
			date=date(2026, 5, 10),
			status='released',
			created_by=self.admin,
		)
		Cheque.objects.create(
			cheque_number='000002',
			payee=supplier,
			payee_name='Cheque Supplier',
			fund_cluster=fund_two,
			amount=Decimal('200.00'),
			date=date(2026, 5, 11),
			status='released',
			created_by=self.admin,
		)

		snapshot = views._build_report_snapshot('cheque_summary', '2026-05-01', '2026-05-31', fund_cluster_id=fund_one.pk)

		self.assertEqual(snapshot['fund_cluster_id'], fund_one.pk)
		self.assertEqual(snapshot['fund_cluster'], str(fund_one))
		self.assertEqual(snapshot['bank_account'], 'Bank A / 111-222')
		self.assertEqual(snapshot['cheque_count'], 1)
		self.assertEqual(len(snapshot['rows']), 1)

	def test_generate_report_uses_selected_preview_rows(self):
		cheque_one = Cheque.objects.create(
			cheque_number='000101',
			payee=self.supplier,
			payee_name=self.supplier.account_name,
			amount=Decimal('150.00'),
			date=date(2026, 5, 1),
			status='released',
			created_by=self.admin,
		)
		Cheque.objects.create(
			cheque_number='000102',
			payee=self.supplier,
			payee_name=self.supplier.account_name,
			amount=Decimal('175.00'),
			date=date(2026, 5, 2),
			status='released',
			created_by=self.admin,
		)

		self.client.force_login(self.admin)
		response = self.client.post(reverse('reports'), data={
			'report_type': 'cheque_summary',
			'cheque_status': 'released',
			'date_from': '2026-05-01',
			'date_to': '2026-05-31',
			'selected_rows': str(cheque_one.pk),
		})

		self.assertEqual(response.status_code, 302)
		report = Report.objects.latest('generated_at')
		self.assertEqual(report.report_type, 'cheque_summary')
		self.assertEqual(len(report.data_snapshot['rows']), 1)
		self.assertEqual(report.data_snapshot['rows'][0]['id'], cheque_one.pk)

	def test_edit_report_previews_live_rows_and_updates_same_record(self):
		first_cheque = Cheque.objects.create(
			cheque_number='000201',
			payee=self.supplier,
			payee_name=self.supplier.account_name,
			amount=Decimal('210.00'),
			date=date(2026, 5, 3),
			status='released',
			created_by=self.admin,
		)
		second_cheque = Cheque.objects.create(
			cheque_number='000202',
			payee=self.supplier,
			payee_name=self.supplier.account_name,
			amount=Decimal('220.00'),
			date=date(2026, 5, 4),
			status='released',
			created_by=self.admin,
		)

		self.client.force_login(self.admin)
		create_response = self.client.post(reverse('reports'), data={
			'report_type': 'cheque_summary',
			'cheque_status': 'released',
			'date_from': '2026-05-01',
			'date_to': '2026-05-31',
			'selected_rows': str(first_cheque.pk),
		})
		self.assertEqual(create_response.status_code, 302)
		report = Report.objects.latest('generated_at')
		original_report_id = report.pk

		preview_response = self.client.get(
			reverse('report_export_preview'),
			data={
				'report_type': 'cheque_summary',
				'edit_report_id': str(report.pk),
			},
		)
		self.assertEqual(preview_response.status_code, 200)
		preview_data = preview_response.json()
		self.assertEqual(preview_data['row_count'], 2)
		self.assertEqual(preview_data['selected_row_ids'], [str(first_cheque.pk)])

		update_response = self.client.post(
			reverse('reports'),
			data={
				'report_id': str(report.pk),
				'selected_rows': str(second_cheque.pk),
			},
		)
		self.assertEqual(update_response.status_code, 302)
		report.refresh_from_db()
		self.assertEqual(report.pk, original_report_id)
		self.assertEqual(len(report.data_snapshot['rows']), 1)
		self.assertEqual(report.data_snapshot['rows'][0]['id'], second_cheque.pk)


class SupplierGrossCalculationTests(TestCase):
	def setUp(self):
		self.admin = User.objects.create_superuser(username='admin', email='admin@example.com', password='pass12345')
		from admin_panel.models import ManagementOption
		ManagementOption.objects.filter(category=ManagementOption.CATEGORY_TAX).delete()
		ManagementOption.objects.create(category=ManagementOption.CATEGORY_TAX, value='Tax (5%/3%)', uacs='5%/3%', is_active=True)
		ManagementOption.objects.create(category=ManagementOption.CATEGORY_TAX, value='Tax (2%/1%)', uacs='2%/1%', is_active=True)

	def test_supplier_creation_gross_calculation_vat(self):
		self.client.force_login(self.admin)
		response = self.client.post(
			reverse('suppliers'),
			data={
				'action': 'create',
				'payee': 'VAT Supplier Test',
				'amount': '8640.00',
				'gross_amount': '8640.00',
				'is_vat': 'on',
				'goods_service_type': 'services',
				'other_deductions': '150.00',
				'enable_professional_tax': 'on',
			},
			follow=True,
		)
		self.assertEqual(response.status_code, 200)
		self.assertIn("added", str(response.context.get('success', '') or ''))
		supplier = Supplier.objects.get(account_name='VAT Supplier Test')
		extras = supplier.raw_import.get('supplier_extras') or {}
		# base = 8640/1.12 = 7714.29; tax_5 = 5% → 385.71; services 2% → 154.29; prof 5% → 432.00
		self.assertEqual(extras.get('tax_5'), '385.71')
		self.assertEqual(extras.get('tax_2'), '154.29')
		self.assertEqual(extras.get('goods_service_type'), 'services')
		self.assertEqual(extras.get('professional_tax'), '432.00')
		self.assertEqual(extras.get('gross_amount'), '8640.00')
		self.assertEqual(extras.get('net_amount'), '7518.00')

	def test_supplier_creation_professional_tax_disabled(self):
		self.client.force_login(self.admin)
		response = self.client.post(
			reverse('suppliers'),
			data={
				'action': 'create',
				'payee': 'No Prof Tax Supplier',
				'amount': '8640.00',
				'gross_amount': '8640.00',
				'is_vat': 'on',
				'goods_service_type': 'services',
				'other_deductions': '150.00',
			},
			follow=True,
		)
		self.assertEqual(response.status_code, 200)
		self.assertIn("added", str(response.context.get('success', '') or ''))
		supplier = Supplier.objects.get(account_name='No Prof Tax Supplier')
		extras = supplier.raw_import.get('supplier_extras') or {}
		# Enable unchecked → prof tax 0; net = 8640 - 385.71 - 154.29 - 150 = 7950.00
		self.assertEqual(extras.get('professional_tax'), '0.00')
		self.assertEqual(extras.get('professional_tax_rate'), '0.00')
		self.assertEqual(extras.get('net_amount'), '7950.00')

	def test_supplier_creation_gross_calculation_non_vat(self):
		self.client.force_login(self.admin)
		response = self.client.post(
			reverse('suppliers'),
			data={
				'action': 'create',
				'payee': 'Non-VAT Supplier Test',
				'amount': '8640.00',
				'gross_amount': '8640.00',
				'is_vat': '',
				'goods_service_type': 'goods',
				'other_deductions': '150.00',
				'enable_professional_tax': 'on',
			},
			follow=True,
		)
		self.assertEqual(response.status_code, 200)
		self.assertIn("added", str(response.context.get('success', '') or ''))
		supplier = Supplier.objects.get(account_name='Non-VAT Supplier Test')
		extras = supplier.raw_import.get('supplier_extras') or {}
		# Non-VAT base = gross; tax_5 = 3% → 259.20; goods 1% → 86.40; prof 5% → 432.00; other 150 → net 7712.40
		self.assertEqual(extras.get('tax_5'), '259.20')
		self.assertEqual(extras.get('tax_2'), '86.40')
		self.assertEqual(extras.get('goods_service_type'), 'goods')
		self.assertEqual(extras.get('professional_tax'), '432.00')
		self.assertEqual(extras.get('gross_amount'), '8640.00')
		self.assertEqual(extras.get('net_amount'), '7712.40')

	def test_supplier_creation_with_percent_sign_in_rate(self):
		self.client.force_login(self.admin)
		response = self.client.post(
			reverse('suppliers'),
			data={
				'action': 'create',
				'payee': 'Percent Sign Supplier Test',
				'amount': '8640.00',
				'gross_amount': '8640.00',
				'is_vat': '',
				'goods_service_type': 'services',
				'other_deductions': '150.00',
				'enable_professional_tax': 'on',
			},
			follow=True,
		)
		self.assertEqual(response.status_code, 200)
		self.assertIn("added", str(response.context.get('success', '') or ''))
		supplier = Supplier.objects.get(account_name='Percent Sign Supplier Test')
		extras = supplier.raw_import.get('supplier_extras') or {}
		# Non-VAT + services 2% → 172.80; prof still forced 5% of gross
		self.assertEqual(extras.get('tax_5'), '259.20')
		self.assertEqual(extras.get('tax_2'), '172.80')
		self.assertEqual(extras.get('goods_service_type'), 'services')
		self.assertEqual(extras.get('professional_tax'), '432.00')
		self.assertEqual(extras.get('gross_amount'), '8640.00')

	def test_supplier_creation_with_extra_tax_slot(self):
		self.client.force_login(self.admin)
		response = self.client.post(
			reverse('suppliers'),
			data={
				'action': 'create',
				'payee': 'Extra Tax Slot Supplier',
				'amount': '10000.00',
				'gross_amount': '10000.00',
				'is_vat': '',
				'goods_service_type': '',
				'other_deductions': '0.00',
				'tax_1_option': '3',
				'tax_3_option': '7',
			},
			follow=True,
		)
		self.assertEqual(response.status_code, 200)
		self.assertIn("added", str(response.context.get('success', '') or ''))
		supplier = Supplier.objects.get(account_name='Extra Tax Slot Supplier')
		extras = supplier.raw_import.get('supplier_extras') or {}
		# Non-VAT: tax_5 = 3% of 10000 = 300.00; tax_3 = 7% of 10000 = 700.00
		self.assertEqual(extras.get('tax_5'), '300.00')
		self.assertEqual(extras.get('tax_3'), '700.00')
		self.assertEqual(extras.get('tax_3_option'), '7.00')
		# net = 10000 - 300 - 700 = 9000.00
		self.assertEqual(extras.get('net_amount'), '9000.00')

	def test_supplier_creation_tax_type_none(self):
		self.client.force_login(self.admin)
		response = self.client.post(
			reverse('suppliers'),
			data={
				'action': 'create',
				'payee': 'Tax Type None Supplier',
				'amount': '10000.00',
				'gross_amount': '10000.00',
				'tax_type': 'none',
				'goods_service_type': 'services',
				'other_deductions': '50.00',
				'enable_professional_tax': 'on',
				'tax_1_option': '5',
				'tax_3_option': '7',
			},
			follow=True,
		)
		self.assertEqual(response.status_code, 200)
		self.assertIn("added", str(response.context.get('success', '') or ''))
		supplier = Supplier.objects.get(account_name='Tax Type None Supplier')
		extras = supplier.raw_import.get('supplier_extras') or {}
		self.assertEqual(extras.get('tax_type'), 'none')
		self.assertEqual(extras.get('tax_exempt'), 'true')
		self.assertEqual(extras.get('is_vat'), 'false')
		self.assertEqual(extras.get('tax_5'), '0.00')
		self.assertEqual(extras.get('tax_2'), '0.00')
		self.assertEqual(extras.get('tax_3'), '0.00')
		self.assertEqual(extras.get('goods_service_type'), '')
		# Prof. Tax is independent of Tax Type=None — still applies when Enable is on
		self.assertEqual(extras.get('professional_tax'), '500.00')
		self.assertEqual(extras.get('professional_tax_rate'), '5.00')
		# net = 10000 - 0 - 0 - 0 - 500 - 50 = 9450.00
		self.assertEqual(extras.get('net_amount'), '9450.00')

	def test_supplier_creation_tax_type_vat(self):
		self.client.force_login(self.admin)
		self.client.post(
			reverse('suppliers'),
			data={
				'action': 'create',
				'payee': 'Tax Type Vat Supplier',
				'amount': '11200.00',
				'gross_amount': '11200.00',
				'tax_type': 'vat',
				'goods_service_type': '',
				'other_deductions': '0.00',
				'tax_1_option': '5',
			},
			follow=True,
		)
		supplier = Supplier.objects.get(account_name='Tax Type Vat Supplier')
		extras = supplier.raw_import.get('supplier_extras') or {}
		self.assertEqual(extras.get('tax_type'), 'vat')
		self.assertEqual(extras.get('is_vat'), 'true')
		self.assertEqual(extras.get('tax_exempt'), 'false')
		# base = 11200/1.12 = 10000; 5% → 500.00
		self.assertEqual(extras.get('tax_5'), '500.00')

	def test_supplier_creation_tax_type_custom(self):
		"""Legacy tax_type='custom' post still accepted (rate option 'custom' is the UI path)."""
		self.client.force_login(self.admin)
		response = self.client.post(
			reverse('suppliers'),
			data={
				'action': 'create',
				'payee': 'Tax Type Custom Supplier',
				'amount': '10000.00',
				'gross_amount': '10000.00',
				'tax_type': 'custom',
				'goods_service_type': 'services',
				'other_deductions': '10.00',
				'enable_professional_tax': 'on',
				'tax_1_option': '5',
				'tax_5': '222.22',
				'tax_2': '33.33',
				'tax_4': '44.44',
				'tax_4_option': '7',
			},
			follow=True,
		)
		self.assertEqual(response.status_code, 200)
		self.assertIn("added", str(response.context.get('success', '') or ''))
		supplier = Supplier.objects.get(account_name='Tax Type Custom Supplier')
		extras = supplier.raw_import.get('supplier_extras') or {}
		self.assertEqual(extras.get('tax_type'), 'custom')
		self.assertEqual(extras.get('tax_exempt'), 'false')
		self.assertEqual(extras.get('is_vat'), 'false')
		# Posted amounts kept as-is — NOT recomputed from rates (5% of 10000 would be 500.00)
		self.assertEqual(extras.get('tax_5'), '222.22')
		self.assertEqual(extras.get('tax_2'), '33.33')
		self.assertEqual(extras.get('tax_4'), '44.44')
		self.assertEqual(extras.get('tax_4_option'), '7.00')
		# Prof. Tax still applies under Custom when Enable is on
		self.assertEqual(extras.get('professional_tax'), '500.00')
		# net = 10000 - 222.22 - 33.33 - 44.44 - 500 - 10 = 9190.01
		self.assertEqual(extras.get('net_amount'), '9190.01')

	def test_supplier_creation_custom_rate_option(self):
		"""Tax rate dropdowns: option 'custom' → posted amounts win, stored for edit restore."""
		self.client.force_login(self.admin)
		response = self.client.post(
			reverse('suppliers'),
			data={
				'action': 'create',
				'payee': 'Custom Rate Supplier',
				'amount': '10000.00',
				'gross_amount': '10000.00',
				'tax_type': 'non_vat',
				'goods_service_type': 'custom',
				'other_deductions': '10.00',
				'enable_professional_tax': 'on',
				'tax_1_option': 'custom',
				'tax_5': '222.22',
				'tax_2': '33.33',
				'tax_4': '44.44',
				'tax_4_option': 'custom',
			},
			follow=True,
		)
		self.assertEqual(response.status_code, 200)
		self.assertIn("added", str(response.context.get('success', '') or ''))
		supplier = Supplier.objects.get(account_name='Custom Rate Supplier')
		extras = supplier.raw_import.get('supplier_extras') or {}
		# Custom markers survive so edit restore re-selects them
		self.assertEqual(extras.get('tax_1_option'), 'custom')
		self.assertEqual(extras.get('goods_service_type'), 'custom')
		self.assertEqual(extras.get('tax_4_option'), 'custom')
		# Posted amounts win over rate computation (3% of 10000 would be 300.00)
		self.assertEqual(extras.get('tax_5'), '222.22')
		self.assertEqual(extras.get('tax_2'), '33.33')
		self.assertEqual(extras.get('tax_4'), '44.44')
		# net = 10000 - 222.22 - 33.33 - 44.44 - 500 - 10 = 9190.01
		self.assertEqual(extras.get('net_amount'), '9190.01')
		# Enrichment keeps 'custom' for the edit button data attributes
		views._enrich_supplier_for_display(supplier)
		self.assertEqual(supplier.goods_service_type, 'custom')
		self.assertEqual(supplier.tax_1_option, 'custom')

	def test_tax_1_option_follows_vat_mode(self):
		"""VAT posts 5% · Non-VAT posts 3% even if the other side is sent (dual rate)."""
		self.client.force_login(self.admin)
		# Non-VAT but stale 5% option → backend should use 3%
		self.client.post(
			reverse('suppliers'),
			data={
				'action': 'create',
				'payee': 'Dual Rate NonVat',
				'amount': '10000.00',
				'gross_amount': '10000.00',
				'is_vat': '',
				'goods_service_type': '',
				'other_deductions': '0.00',
				'tax_1_option': '5',
			},
			follow=True,
		)
		sup_nv = Supplier.objects.get(account_name='Dual Rate NonVat')
		ex_nv = sup_nv.raw_import.get('supplier_extras') or {}
		self.assertEqual(ex_nv.get('tax_1_option'), '3.00')
		self.assertEqual(ex_nv.get('tax_5'), '300.00')

		# VAT but stale 3% option → backend should use 5%
		self.client.post(
			reverse('suppliers'),
			data={
				'action': 'create',
				'payee': 'Dual Rate Vat',
				'amount': '11200.00',
				'gross_amount': '11200.00',
				'is_vat': 'on',
				'goods_service_type': '',
				'other_deductions': '0.00',
				'tax_1_option': '3',
			},
			follow=True,
		)
		sup_v = Supplier.objects.get(account_name='Dual Rate Vat')
		ex_v = sup_v.raw_import.get('supplier_extras') or {}
		self.assertEqual(ex_v.get('tax_1_option'), '5.00')
		# base = 11200/1.12 = 10000; 5% → 500.00
		self.assertEqual(ex_v.get('tax_5'), '500.00')

	def test_supplier_import_auto_vat_detection(self):
		from cashier.models import FundCluster
		FundCluster.objects.get_or_create(code='164', defaults={'name': 'General Fund'})

		rows = [
			{
				'PAYEE': 'Imported Non-VAT Supplier',
				'OR NUMBER': '1-90005',
				'AMOUNT': '1000.00',
				'PROFESSIONAL TAX': '30.00',
				'TAX 5%': '0.00',
				'TAX 2%': '0.00',
				'FUND CLUSTER': '164',
			},
			{
				'PAYEE': 'Imported VAT Supplier',
				'OR NUMBER': '1-90006',
				'AMOUNT': '1000.00',
				'PROFESSIONAL TAX': '30.00',
				'TAX 5%': '50.00',
				'TAX 2%': '10.00',
				'FUND CLUSTER': '164',
			}
		]
		from admin_panel import views
		count, warnings = views._do_import('suppliers', rows, self.admin)
		self.assertEqual(count, 2)

		supplier_nv = Supplier.objects.get(account_name='Imported Non-VAT Supplier')
		extras_nv = supplier_nv.raw_import.get('supplier_extras') or {}
		self.assertEqual(extras_nv.get('is_vat'), 'false')

		supplier_v = Supplier.objects.get(account_name='Imported VAT Supplier')
		extras_v = supplier_v.raw_import.get('supplier_extras') or {}
		self.assertEqual(extras_v.get('is_vat'), 'true')

	def test_supplier_import_other_deductions(self):
		from cashier.models import FundCluster
		FundCluster.objects.get_or_create(code='164', defaults={'name': 'General Fund'})

		rows = [
			{
				'PAYEE': 'Imported Supplier with Deductions',
				'OR NUMBER': '1-90007',
				'AMOUNT': '1000.00',
				'OTHER DEDUCTIONS': '150.00',
				'FUND CLUSTER': '164',
			}
		]
		from admin_panel import views
		count, warnings = views._do_import('suppliers', rows, self.admin)
		self.assertEqual(count, 1)

		supplier = Supplier.objects.get(account_name='Imported Supplier with Deductions')
		extras = supplier.raw_import.get('supplier_extras') or {}
		self.assertEqual(extras.get('other_deductions'), '150.00')

	def test_supplier_import_auto_account_title_by_uacs(self):
		from admin_panel.models import ManagementOption, AccountTitleGroup
		from cashier.models import FundCluster
		FundCluster.objects.get_or_create(code='164', defaults={'name': 'General Fund'})

		# Setup account title options & groups
		ManagementOption.objects.filter(category=ManagementOption.CATEGORY_ACCOUNT_TITLE).delete()
		AccountTitleGroup.objects.all().delete()

		option = ManagementOption.objects.create(
			category=ManagementOption.CATEGORY_ACCOUNT_TITLE,
			value='Traveling Expenses - Local',
			uacs='5020603000',
			is_active=True
		)

		group = AccountTitleGroup.objects.create(
			name='Training Expenses',
			uacs='5020201000'
		)

		rows = [
			{
				'PAYEE': 'UACS Option Supplier',
				'OR NUMBER': '1-90008',
				'AMOUNT': '1000.00',
				'UACS Object Code': '5020603000.0',
				'FUND CLUSTER': '164',
			},
			{
				'PAYEE': 'UACS Group Supplier',
				'OR NUMBER': '1-90009',
				'AMOUNT': '2000.00',
				'UACS Object Code': '5020201000',
				'FUND CLUSTER': '164',
			}
		]

		from admin_panel import views
		count, warnings = views._do_import('suppliers', rows, self.admin)
		self.assertEqual(count, 2)

		supplier_opt = Supplier.objects.get(account_name='UACS Option Supplier')
		extras_opt = supplier_opt.raw_import.get('supplier_extras') or {}
		self.assertEqual(extras_opt.get('account_title'), 'Traveling Expenses - Local')
		self.assertEqual(extras_opt.get('uacs'), '5020603000')

		supplier_grp = Supplier.objects.get(account_name='UACS Group Supplier')
		extras_grp = supplier_grp.raw_import.get('supplier_extras') or {}
		self.assertEqual(extras_grp.get('account_title'), 'Training Expenses')
		self.assertEqual(extras_grp.get('uacs'), '5020201000')

	def test_supplier_import_auto_detects_custom_tax_rates(self):
		from cashier.models import FundCluster
		FundCluster.objects.get_or_create(code='164', defaults={'name': 'General Fund'})

		# Row with EWT calculated at 1.00% (e.g. goods purchase under VAT)
		rows = [
			{
				'PAYEE': 'Auto Rate Detection Supplier',
				'OR NUMBER': '1-90010',
				'AMOUNT': '3686.81',
				'TAX 5%': '173.91',
				'TAX 2%': '34.78',
				'GROSS AMOUNT': '3895.50',
				'FUND CLUSTER': '164',
			}
		]

		from admin_panel import views
		count, warnings = views._do_import('suppliers', rows, self.admin)
		self.assertEqual(count, 1)

		supplier = Supplier.objects.get(account_name='Auto Rate Detection Supplier')
		extras = supplier.raw_import.get('supplier_extras') or {}
		self.assertEqual(extras.get('tax_5_rate_vat'), '5.00')
		self.assertEqual(extras.get('tax_2_rate_vat'), '1.00')

		# Verify fallback calculation in _enrich_supplier_for_display resolves to the same values
		# when raw tax values are None (testing the mathematical resolution logic)
		extras['tax_5'] = None
		extras['tax_2'] = None
		supplier.raw_import['supplier_extras'] = extras
		supplier.save()

		views._enrich_supplier_for_display(supplier)
		self.assertEqual(supplier.tax_5, '173.91')
		self.assertEqual(supplier.tax_2, '34.78')
		self.assertEqual(supplier.gross_amount, '3895.50')

		# Verify compute_bucket_taxes uses default 2% rate for EWT -> 70.23 EWT, 175.56 VAT, 3932.60 Gross
		res = views.compute_bucket_taxes(Decimal('3686.81'))
		self.assertEqual(res['tax_5'], Decimal('175.56'))
		self.assertEqual(res['tax_2'], Decimal('70.23'))
		self.assertEqual(res['gross'], Decimal('3932.60'))


class ChequeDeletionTests(TestCase):
	def setUp(self):
		self.admin = User.objects.create_superuser(username='admin', email='admin@example.com', password='pass12345')
		self.client.force_login(self.admin)
		self.fund = FundCluster.objects.create(code='FC-1', name='Fund 1', balance=Decimal('5000.00'))
		self.cheque = Cheque.objects.create(
			cheque_number='111111',
			payee_name='Test Payee',
			amount=Decimal('1000.00'),
			date=date.today(),
			status='draft',
			created_by=self.admin,
			fund_cluster=self.fund
		)

	def test_delete_draft_cheque_succeeds(self):
		response = self.client.post(reverse('cheque_delete', args=[self.cheque.pk]))
		self.assertEqual(response.status_code, 302)
		self.assertFalse(Cheque.objects.filter(pk=self.cheque.pk).exists())

	def test_delete_released_cheque_fails(self):
		self.cheque.status = 'released'
		self.cheque.save()
		response = self.client.post(reverse('cheque_delete', args=[self.cheque.pk]))
		self.assertEqual(response.status_code, 302)
		self.assertIn('error=Released%20cheques%20cannot%20be%20deleted.', response.url)
		self.assertTrue(Cheque.objects.filter(pk=self.cheque.pk).exists())

	def test_delete_released_cheque_ajax_fails(self):
		self.cheque.status = 'released'
		self.cheque.save()
		response = self.client.post(
			reverse('cheque_delete', args=[self.cheque.pk]),
			HTTP_X_REQUESTED_WITH='XMLHttpRequest'
		)
		self.assertEqual(response.status_code, 400)
		data = response.json()
		self.assertFalse(data['ok'])
		self.assertEqual(data['error'], 'Released cheques cannot be deleted.')
		self.assertTrue(Cheque.objects.filter(pk=self.cheque.pk).exists())


class ChequeNumberFormatTests(TestCase):
	def test_normalize_cheque_number_freeform(self):
		# Alpha-numeric formats and spaces/hyphens are allowed
		self.assertEqual(Cheque.normalize_cheque_number('ABC-123'), 'ABC-123')
		self.assertEqual(Cheque.normalize_cheque_number('123 456 XY'), '123 456 XY')
		self.assertEqual(Cheque.normalize_cheque_number('MAY 26-001'), 'MAY 26-001')

	def test_normalize_cheque_number_padding(self):
		# Purely numeric short strings are still zero-padded to width (default 6)
		self.assertEqual(Cheque.normalize_cheque_number('123'), '000123')
		self.assertEqual(Cheque.normalize_cheque_number('5'), '000005')
		# If numeric and already at or above width, it is kept as-is
		self.assertEqual(Cheque.normalize_cheque_number('1234567'), '1234567')

	def test_record_generated_cheque_number_handles_freeform(self):
		# Non-numeric string shouldn't crash record_generated_cheque_number
		res = Cheque.record_generated_cheque_number('ABC-123')
		self.assertEqual(res, 'ABC-123')


class AboutSystemTests(TestCase):
	def setUp(self):
		self.admin = User.objects.create_superuser(username='admin', email='admin@example.com', password='pass12345')
		self.client.force_login(self.admin)

	def test_about_system_accessible(self):
		response = self.client.get(reverse('about_system'))
		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Dee Jay B. Cristobal')
		self.assertContains(response, 'Registry Cheque Management System')
		self.assertContains(response, 'Cashiering Services')


class AboutCashierTests(TestCase):
	def setUp(self):
		self.admin = User.objects.create_superuser(username='admin', email='admin@example.com', password='pass12345')
		self.client.force_login(self.admin)

	def test_about_cashier_redirects_to_about(self):
		response = self.client.get(reverse('about_cashier'))
		self.assertEqual(response.status_code, 302)
		self.assertRedirects(response, reverse('about_system'))


class DisbursingOfficerTests(TestCase):
	def setUp(self):
		self.admin = User.objects.create_superuser(username='admin', email='admin@example.com', password='pass12345')
		self.client.force_login(self.admin)
		self.cashier1 = User.objects.create_user(username='cashier1', email='cashier1@example.com', password='pass12345', first_name='John', last_name='Doe')
		self.cashier2 = User.objects.create_user(username='cashier2', email='cashier2@example.com', password='pass12345', first_name='Jane', last_name='Smith')
		
		# create profiles
		from cashier.models import Profile
		self.profile1, _ = Profile.objects.get_or_create(user=self.cashier1, defaults={'role': 'cashier'})
		self.profile2, _ = Profile.objects.get_or_create(user=self.cashier2, defaults={'role': 'cashier'})

	def test_get_certification_name_defaults_to_passed_user(self):
		from admin_panel.views import _get_certification_name
		name = _get_certification_name(self.cashier1)
		self.assertIn('John', name)
		self.assertIn('Doe', name)

	def test_get_certification_name_retrieves_disbursing_officer(self):
		from admin_panel.views import _get_certification_name
		self.profile2.is_disbursing_officer = True
		self.profile2.save()
		
		name = _get_certification_name(self.cashier1)
		self.assertIn('Jane', name)
		self.assertIn('Smith', name)

	def test_create_user_with_disbursing_officer_fails_if_already_set(self):
		self.profile1.is_disbursing_officer = True
		self.profile1.save()

		post_data = {
			'action': 'create',
			'admin_password': 'pass12345',
			'first_name': 'Alice',
			'last_name': 'Brown',
			'middle_initial': 'B',
			'email': 'alice@example.com',
			'username': 'alice1',
			'password': 'Password123!',
			'role': 'cashier',
			'is_disbursing_officer': 'on',
		}
		response = self.client.post(reverse('user_management'), data=post_data)
		# Should return 200 with an error, not 302 redirect
		self.assertEqual(response.status_code, 200)
		self.assertIn("A Disbursing Officer is already set", response.content.decode())

		self.profile1.refresh_from_db()
		self.assertTrue(self.profile1.is_disbursing_officer)
		# User alice1 should not have been created
		self.assertFalse(User.objects.filter(username='alice1').exists())

	def test_create_user_with_disbursing_officer_succeeds_if_none_set(self):
		self.profile1.is_disbursing_officer = False
		self.profile1.save()

		response = self.client.post(reverse('user_management'), data={
			'action': 'create',
			'admin_password': 'pass12345',
			'first_name': 'Alice',
			'last_name': 'Brown',
			'middle_initial': 'B',
			'email': 'alice@example.com',
			'username': 'alice1',
			'password': 'Password123!',
			'role': 'cashier',
			'is_disbursing_officer': 'on',
		})
		self.assertEqual(response.status_code, 302)

		import hashlib
		from cashier.models import Profile
		alice_profile = Profile.objects.get(
			email_hash=hashlib.sha256(b'alice@example.com').hexdigest()
		)
		self.assertTrue(alice_profile.is_disbursing_officer)

	def test_edit_user_with_disbursing_officer_fails_if_already_set(self):
		self.profile1.is_disbursing_officer = True
		self.profile1.save()

		post_data = {
			'action': 'edit',
			'user_id': self.cashier2.id,
			'admin_password': 'pass12345',
			'first_name': 'Jane',
			'last_name': 'Smith',
			'middle_initial': 'S',
			'email': 'cashier2@example.com',
			'username': 'cashier2',
			'role': 'cashier',
			'is_disbursing_officer': 'on',
		}
		response = self.client.post(reverse('user_management'), data=post_data)
		self.assertEqual(response.status_code, 200)
		self.assertIn("A Disbursing Officer is already set", response.content.decode())

		self.profile1.refresh_from_db()
		self.profile2.refresh_from_db()
		self.assertTrue(self.profile1.is_disbursing_officer)
		self.assertFalse(self.profile2.is_disbursing_officer)

	def test_edit_user_with_disbursing_officer_succeeds_if_none_set(self):
		self.profile1.is_disbursing_officer = False
		self.profile1.save()

		post_data = {
			'action': 'edit',
			'user_id': self.cashier2.id,
			'admin_password': 'pass12345',
			'first_name': 'Jane',
			'last_name': 'Smith',
			'middle_initial': 'S',
			'email': 'cashier2@example.com',
			'username': 'cashier2',
			'role': 'cashier',
			'is_disbursing_officer': 'on',
		}
		response = self.client.post(reverse('user_management'), data=post_data)
		self.assertEqual(response.status_code, 302)

		self.profile2.refresh_from_db()
		self.assertTrue(self.profile2.is_disbursing_officer)

	def test_employee_id_auto_generation(self):
		# Clear existing employee IDs
		from cashier.models import Profile
		Profile.objects.all().update(employee_id=None)

		# Add some manual/custom IDs for all profiles so none are empty
		admin_profile = Profile.objects.get(user=self.admin)
		admin_profile.employee_id = "EMP-2024-00001"
		admin_profile.save()

		self.profile1.employee_id = "EMP-2024-00158"
		self.profile1.save()
		self.profile2.employee_id = "159"
		self.profile2.save()

		response = self.client.get(reverse('user_management'))
		self.assertEqual(response.status_code, 200)
		next_employee_id = response.context['next_employee_id']
		
		# The max ID number was 159 (from "159"). The next should be 160.
		from datetime import datetime
		expected_year = datetime.now().year
		self.assertEqual(next_employee_id, f"EMP-{expected_year}-00160")

	def test_create_user_with_admin_role_fails_if_already_set(self):
		# Set profile1 as admin
		self.profile1.role = 'admin'
		self.profile1.save()

		post_data = {
			'action': 'create',
			'admin_password': 'pass12345',
			'first_name': 'Alice',
			'last_name': 'Brown',
			'middle_initial': 'B',
			'email': 'alice@example.com',
			'username': 'alice1',
			'password': 'Password123!',
			'role': 'admin',
		}
		response = self.client.post(reverse('user_management'), data=post_data)
		self.assertEqual(response.status_code, 200)
		self.assertIn("An Admin account is already set", response.content.decode())
		
		# User alice1 should not have been created
		self.assertFalse(User.objects.filter(username='alice1').exists())

	def test_edit_user_to_admin_role_fails_if_already_set(self):
		# Set profile1 as admin
		self.profile1.role = 'admin'
		self.profile1.save()

		post_data = {
			'action': 'edit',
			'user_id': self.cashier2.id,
			'admin_password': 'pass12345',
			'first_name': 'Jane',
			'last_name': 'Smith',
			'middle_initial': 'S',
			'email': 'cashier2@example.com',
			'username': 'cashier2',
			'role': 'admin',
		}
		response = self.client.post(reverse('user_management'), data=post_data)
		self.assertEqual(response.status_code, 200)
		self.assertIn("An Admin account is already set", response.content.decode())

		self.profile2.refresh_from_db()
		self.assertEqual(self.profile2.role, 'cashier')

	def test_missing_employee_id_auto_regeneration_on_get(self):
		from cashier.models import Profile
		# Set profile1's employee_id to None
		self.profile1.employee_id = None
		self.profile1.save()

		# Ensure profile2 and admin have starting IDs so we control max suffix
		self.profile2.employee_id = "EMP-2024-00100"
		self.profile2.save()
		admin_profile = Profile.objects.get(user=self.admin)
		admin_profile.employee_id = "EMP-2024-00001"
		admin_profile.save()

		# Load the user management page
		response = self.client.get(reverse('user_management'))
		self.assertEqual(response.status_code, 200)

		# profile1 should have been automatically assigned the next ID: EMP-YYYY-00101
		self.profile1.refresh_from_db()
		self.assertIsNotNone(self.profile1.employee_id)
		self.assertTrue(self.profile1.employee_id.startswith("EMP-"))
		self.assertIn("00101", self.profile1.employee_id)




class SystemResetTests(TestCase):
	def setUp(self):
		self.admin = User.objects.create_superuser(username='admin', email='admin@example.com', password='pass12345')
		self.client.force_login(self.admin)
		
		# Create extra non-admin user
		self.other_user = User.objects.create_user(username='cashier1', email='cashier1@example.com', password='pass12345')
		from cashier.models import Profile, Transaction, Cheque, Supplier, Report, FundCluster, RoleConfig
		from admin_panel.models import AuditLog, SystemSetting, AccountTitleGroup, ManagementOption
		Profile.objects.get_or_create(user=self.other_user, defaults={'role': 'cashier'})
		Profile.objects.get_or_create(user=self.admin, defaults={'role': 'admin'})
		
		# Create transactional data
		self.supplier = Supplier.objects.create(account_name="Supplier Alpha")
		self.cheque = Cheque.objects.create(cheque_number="123456", payee=self.supplier, amount=Decimal("500.00"))
		self.transaction = Transaction.objects.create(student_name="Alice", amount=Decimal("100.00"))
		self.report = Report.objects.create(title="Monthly Report", report_type="cheque_summary", generated_by=self.admin)
		
		# Create operational/config data
		self.fund_cluster = FundCluster.objects.create(code="101", name="General Fund", balance=Decimal("1000.00"))
		self.account_group = AccountTitleGroup.objects.create(name="Cash in Bank")
		self.mgmt_option = ManagementOption.objects.create(category=ManagementOption.CATEGORY_ACCOUNT_TITLE, value="Cash")
		self.role_config = RoleConfig.objects.create(role="cashier", config={})
		
		# Clear existing SystemSetting and create custom
		SystemSetting.objects.all().delete()
		self.system_setting = SystemSetting.objects.create(pk=1, system_name="registry_custom")

		# Clear leftover AuditLog rows (keepdb can retain committed rows across runs)
		AuditLog.objects.all().delete()
		AuditLog.objects.create(admin=self.admin, action="Initial Setup")

	def test_system_reset_success_with_correct_password(self):
		from cashier.models import Profile, Transaction, Cheque, Supplier, Report, FundCluster, RoleConfig
		from admin_panel.models import AuditLog, SystemSetting, AccountTitleGroup, ManagementOption

		# Verify initial counts
		self.assertEqual(User.objects.count(), 2)
		self.assertEqual(Profile.objects.count(), 2)
		self.assertEqual(Supplier.objects.count(), 1)
		self.assertEqual(Cheque.objects.count(), 1)
		self.assertEqual(Transaction.objects.count(), 1)
		self.assertEqual(Report.objects.count(), 1)
		self.assertEqual(FundCluster.objects.count(), 1)
		self.assertEqual(AccountTitleGroup.objects.count(), 1)
		self.assertEqual(ManagementOption.objects.count(), 1)
		self.assertEqual(RoleConfig.objects.count(), 1)
		self.assertEqual(SystemSetting.objects.count(), 1)
		self.assertEqual(AuditLog.objects.count(), 1)

		post_data = {
			'action': 'reset',
			'admin_password': 'pass12345',
		}
		response = self.client.post(reverse('backup_restore'), data=post_data)
		self.assertEqual(response.status_code, 200)
		self.assertIn("System has been successfully reset", response.context['success'])

		# Verify all database data is deleted
		self.assertEqual(Supplier.objects.count(), 0)
		self.assertEqual(Cheque.objects.count(), 0)
		self.assertEqual(Transaction.objects.count(), 0)
		self.assertEqual(Report.objects.count(), 0)
		self.assertEqual(FundCluster.objects.count(), 0)
		self.assertEqual(AccountTitleGroup.objects.count(), 0)
		self.assertEqual(ManagementOption.objects.count(), 0)
		self.assertEqual(RoleConfig.objects.count(), 0)

		# SystemSetting should have exactly 1 re-initialized record (the default system setting)
		self.assertEqual(SystemSetting.objects.count(), 1)
		self.assertEqual(SystemSetting.objects.first().system_name, "registry")

		# Verify non-admin users/profiles are deleted but admin user is preserved
		self.assertEqual(User.objects.count(), 1)
		self.assertEqual(User.objects.first(), self.admin)
		self.assertEqual(Profile.objects.count(), 1)
		self.assertEqual(Profile.objects.first().user, self.admin)

		# AuditLog should contain exactly the "System reset executed" action
		self.assertEqual(AuditLog.objects.count(), 1)
		self.assertEqual(AuditLog.objects.first().action, "System reset executed")

	def test_system_reset_failure_with_wrong_password(self):
		from cashier.models import Profile, Transaction, Cheque, Supplier, Report, FundCluster, RoleConfig
		from admin_panel.models import AuditLog, SystemSetting, AccountTitleGroup, ManagementOption

		# Verify initial counts
		self.assertEqual(User.objects.count(), 2)
		self.assertEqual(Profile.objects.count(), 2)
		self.assertEqual(Supplier.objects.count(), 1)
		self.assertEqual(Cheque.objects.count(), 1)
		self.assertEqual(Transaction.objects.count(), 1)
		self.assertEqual(Report.objects.count(), 1)
		self.assertEqual(FundCluster.objects.count(), 1)
		self.assertEqual(AccountTitleGroup.objects.count(), 1)
		self.assertEqual(ManagementOption.objects.count(), 1)
		self.assertEqual(RoleConfig.objects.count(), 1)
		self.assertEqual(SystemSetting.objects.count(), 1)
		self.assertEqual(AuditLog.objects.count(), 1)

		post_data = {
			'action': 'reset',
			'admin_password': 'wrongpassword',
		}
		response = self.client.post(reverse('backup_restore'), data=post_data)
		self.assertEqual(response.status_code, 200)
		self.assertEqual(response.context['error'], "Admin password is incorrect")

		# Verify data is untouched
		self.assertEqual(User.objects.count(), 2)
		self.assertEqual(Profile.objects.count(), 2)
		self.assertEqual(Supplier.objects.count(), 1)
		self.assertEqual(Cheque.objects.count(), 1)
		self.assertEqual(Transaction.objects.count(), 1)
		self.assertEqual(Report.objects.count(), 1)
		self.assertEqual(FundCluster.objects.count(), 1)
		self.assertEqual(AccountTitleGroup.objects.count(), 1)
		self.assertEqual(ManagementOption.objects.count(), 1)
		self.assertEqual(RoleConfig.objects.count(), 1)
		self.assertEqual(SystemSetting.objects.count(), 1)
		self.assertEqual(AuditLog.objects.count(), 1)


class BackupPreviewTests(TestCase):
	"""Backup Data Preview: cheque badges match the live Cheques page,
	and fund clusters show Total Disbursed (released cheques), not balance."""

	@staticmethod
	def _cluster(pk=1):
		return {"model": "cashier.fundcluster", "pk": pk, "fields": {
			"code": "101", "name": "ISABELA STATE UNIVERSITY", "description": "",
			"balance": "0", "bank_name": "LANDBANK", "is_active": True, "is_archived": False,
		}}

	@staticmethod
	def _cheque(pk, status, amount="0.00", fc=1, stale_at=None, archived=False):
		return {"model": "cashier.cheque", "pk": pk, "fields": {
			"cheque_number": f"CHK{pk}", "payee_name": f"Payee {pk}",
			"fund_cluster": fc, "amount": amount, "status": status,
			"stale_at": stale_at, "released_at": None,
			"is_archived": archived,
		}}

	def test_cheque_status_never_shows_draft_or_pending(self):
		from admin_panel.views import _build_data_preview_from_serialized
		yesterday = (date.today() - timedelta(days=1)).isoformat()
		tomorrow = (date.today() + timedelta(days=1)).isoformat()
		raw = [
			self._cluster(),
			self._cheque(1, "pending", amount="100.00"),
			self._cheque(2, "draft", amount="100.00"),
			self._cheque(3, "unreleased", amount="100.00"),
			self._cheque(4, "released", amount="150.00"),
			self._cheque(5, "stale", amount="100.00"),
			self._cheque(6, "unreleased", amount="100.00", stale_at=yesterday),
			self._cheque(7, "unreleased", amount="100.00", stale_at=tomorrow),
			self._cheque(8, "voided", amount="100.00"),
			self._cheque(9, "released", amount="999.00", archived=True),
		]
		preview = _build_data_preview_from_serialized(raw)
		statuses = [c["status"] for c in preview["cheques"]]
		self.assertEqual(statuses, [
			"unreleased",   # legacy 'pending'
			"unreleased",   # legacy 'draft'
			"unreleased",
			"released",
			"stale",
			"stale",        # overdue stale_at
			"unreleased",   # stale_at in the future
			"voided",
			"archived",     # archived wins over released
		])
		for c in preview["cheques"]:
			self.assertNotIn(c["status"], ("draft", "pending"))

	def test_cluster_disbursed_sums_released_cheques_only(self):
		from admin_panel.views import _build_data_preview_from_serialized
		raw = [
			self._cluster(pk=1),
			self._cheque(1, "released", amount="500.00", fc=1),
			self._cheque(2, "released", amount="250.50", fc=1),
			self._cheque(3, "unreleased", amount="999.99", fc=1),
			self._cheque(4, "pending", amount="888.88", fc=1),
			self._cheque(5, "released", amount="42.00", fc=None),
		]
		preview = _build_data_preview_from_serialized(raw)
		fc = preview["fund_clusters"][0]
		self.assertEqual(fc["disbursed"], "750.50")
		self.assertEqual(fc["balance"], "0")  # legacy key kept

	def test_cheque_display_status_helper(self):
		from admin_panel.views import _cheque_display_status
		self.assertEqual(_cheque_display_status({"status": "released"}), "released")
		self.assertEqual(_cheque_display_status({"status": "draft"}), "unreleased")
		self.assertEqual(_cheque_display_status({"status": "pending"}), "unreleased")
		self.assertEqual(_cheque_display_status({"status": "unreleased"}), "unreleased")
		self.assertEqual(_cheque_display_status({"status": "stale"}), "stale")
		self.assertEqual(_cheque_display_status({"status": "voided"}), "voided")
		self.assertEqual(_cheque_display_status({"status": "released", "is_archived": True}), "archived")
		yesterday = (date.today() - timedelta(days=1)).isoformat()
		self.assertEqual(_cheque_display_status({"status": "unreleased", "stale_at": yesterday}), "stale")


class SystemFilesBackupTests(TestCase):
	"""App-code (system files) backup: zip of source only, download-only, no data restore."""

	def setUp(self):
		self.admin = User.objects.create_superuser(username='admin', email='admin@example.com', password='pass12345')
		self.client.force_login(self.admin)
		from admin_panel.models import SystemSetting
		settings_obj = SystemSetting.get_settings()
		if getattr(settings_obj, 'auto_backup_to_downloads', False):
			settings_obj.auto_backup_to_downloads = False
			settings_obj.save(update_fields=['auto_backup_to_downloads'])

	def test_pack_system_files_backup_contains_code_not_data(self):
		import shutil
		import zipfile as zf_mod
		from admin_panel.views import _pack_system_files_backup
		path, name, manifest = _pack_system_files_backup(self.admin)
		try:
			self.assertTrue(name.endswith('_CODE.zip'))
			self.assertEqual(manifest['backup_type'], 'code')
			self.assertGreater(manifest['file_count'], 50)
			with zf_mod.ZipFile(path, 'r') as zf:
				names = zf.namelist()
				self.assertIn('manage.py', names)
				self.assertIn('requirements.txt', names)
				self.assertIn('admin_panel/views.py', names)
				self.assertIn('templates/base.html', names)
				self.assertIn('manifest.json', names)
				self.assertFalse(any('__pycache__' in n for n in names), 'pycache leaked into code backup')
				self.assertFalse(any(n.endswith('.pyc') for n in names), 'pyc leaked into code backup')
				self.assertFalse(any(n.startswith('media/') for n in names), 'media leaked into code backup')
				self.assertFalse(any('.venv/' in n for n in names), '.venv leaked into code backup')
				self.assertFalse(any('db.sqlite3' in n for n in names), 'database leaked into code backup')
		finally:
			shutil.rmtree(path.parent, ignore_errors=True)

	def test_download_code_action_streams_zip(self):
		from admin_panel.views import _get_backup_storage_dir
		response = self.client.post(reverse('backup_restore'), data={
			'action': 'download_code',
			'admin_password': 'pass12345',
		})
		self.assertEqual(response.status_code, 200)
		self.assertEqual(response['Content-Type'], 'application/zip')
		self.assertIn('_CODE.zip', response['Content-Disposition'])
		self.assertEqual(response.content[:2], b'PK')
		# clean up the copy stored in media/backups by this test
		stored = _get_backup_storage_dir() / response['Content-Disposition'].split('filename="')[1].rstrip('"')
		stored.unlink(missing_ok=True)

	def test_download_code_requires_admin_password(self):
		response = self.client.post(
			reverse('backup_restore'),
			data={'action': 'download_code', 'admin_password': 'wrong'},
			HTTP_X_REQUESTED_WITH='XMLHttpRequest',
		)
		self.assertEqual(response.status_code, 400)
		self.assertIn('password', str(response.content).lower())

	def test_code_archive_cannot_be_restored(self):
		import shutil
		from admin_panel.views import _pack_system_files_backup, _get_backup_storage_dir
		path, name, _ = _pack_system_files_backup(self.admin)
		stored = _get_backup_storage_dir() / name
		shutil.copy2(path, stored)
		try:
			response = self.client.post(reverse('backup_restore'), data={
				'action': 'restore_server_backup',
				'filename': name,
				'admin_password': 'pass12345',
			})
			self.assertEqual(response.status_code, 200)
			self.assertIn('system files', str(response.context['error']).lower())
			self.assertIsNone(response.context.get('restore_preview'))
		finally:
			stored.unlink(missing_ok=True)
			shutil.rmtree(path.parent, ignore_errors=True)


class SqlBackupPreviewTests(TestCase):
	"""SQL restore preview: INSERT statements parse into data_preview rows."""

	SQL = r"""-- Registry System Backup (SQL)
-- META {"version": 3, "backup_type": "SQL", "format": "sql", "created_at": "2026-09-25T15:45:43", "created_by_username": "admin", "counts": {"fund_clusters": 1, "suppliers": 1, "cheques": 2}}
SET FOREIGN_KEY_CHECKS=0;
SET UNIQUE_CHECKS=0;

DELETE FROM `cashier_cheque`;
DELETE FROM `cashier_fundcluster`;

-- table: cashier_fundcluster (1 rows)
INSERT INTO `cashier_fundcluster` (`id`, `code`, `name`, `description`, `balance`, `is_active`, `bank_name`, `is_archived`) VALUES (1, '101', 'ISABELA STATE UNIVERSITY', '', '0.00', 1, 'LANDBANK', 0) ON DUPLICATE KEY UPDATE `code`=VALUES(`code`);

-- table: cashier_supplier (1 rows)
INSERT INTO `cashier_supplier` (`id`, `account_name`, `raw_import`, `mr_or`, `amount`, `status`, `is_archived`) VALUES (1, 'ACME', '{"supplier_extras": {"tax_type": "vat", "gross_amount": "1000.00"}}', '2359197', '900.00', 'active', 0) ON DUPLICATE KEY UPDATE `account_name`=VALUES(`account_name`);

-- table: cashier_cheque (2 rows)
INSERT INTO `cashier_cheque` (`id`, `cheque_number`, `payee_name`, `fund_cluster_id`, `amount`, `date`, `status`, `stale_at`, `is_archived`, `purpose`) VALUES (1, '2359197', '5G TRADING', 1, '13533.93', '2026-09-24', 'pending', NULL, 0, 'Pay ''special'' fee\nline2') ON DUPLICATE KEY UPDATE `cheque_number`=VALUES(`cheque_number`);
INSERT INTO `cashier_cheque` (`id`, `cheque_number`, `payee_name`, `fund_cluster_id`, `amount`, `date`, `status`, `stale_at`, `is_archived`, `purpose`) VALUES (2, '2359173', 'A.C.S. W3', 1, '52250.00', '2026-09-24', 'released', NULL, 0, 'Facilitation') ON DUPLICATE KEY UPDATE `cheque_number`=VALUES(`cheque_number`);
SET UNIQUE_CHECKS=1;
SET FOREIGN_KEY_CHECKS=1;
"""

	def test_sql_dump_parser_builds_preview_rows(self):
		from admin_panel.views import _sql_dump_to_serialized, _build_data_preview_from_serialized
		objects = _sql_dump_to_serialized(self.SQL)
		preview = _build_data_preview_from_serialized(objects)
		self.assertEqual(len(preview['fund_clusters']), 1)
		self.assertEqual(len(preview['cheques']), 2)
		self.assertEqual(len(preview['suppliers']), 1)
		# legacy 'pending' normalizes to Unreleased, released stays Released
		self.assertEqual([c['status'] for c in preview['cheques']], ['unreleased', 'released'])
		# disbursed = sum of released cheques only (pending excluded)
		self.assertEqual(preview['fund_clusters'][0]['disbursed'], '52250.00')
		purposes = {c['cheque_number']: c['purpose'] for c in preview['cheques']}
		# '' escaping and \n escape decode correctly
		self.assertEqual(purposes['2359197'], "Pay 'special' fee\nline2")
		# FK column fund_cluster_id mapped onto field fund_cluster (join key works)
		self.assertEqual(str(preview['cheques'][0]['fund_cluster']), '1')
		self.assertEqual(str(preview['fund_clusters'][0]['id']), '1')

	def test_sql_dump_parser_decodes_json_columns(self):
		from admin_panel.views import _sql_dump_to_serialized, _build_data_preview_from_serialized
		preview = _build_data_preview_from_serialized(_sql_dump_to_serialized(self.SQL))
		sup = preview['suppliers'][0]
		self.assertEqual(sup['account_name'], 'ACME')
		# raw_import decoded from SQL string to dict so extras render
		self.assertEqual(sup['gross_amount'], '1000.00')

	def test_inspect_sql_backup_returns_nonempty_preview(self):
		import tempfile
		from pathlib import Path as _Path
		from admin_panel.views import _inspect_sql_backup
		with tempfile.NamedTemporaryFile('w', suffix='.sql', delete=False, encoding='utf-8') as fh:
			fh.write(self.SQL)
			sql_path = _Path(fh.name)
		try:
			result = _inspect_sql_backup(sql_path)
			self.assertEqual(len(result['data_preview']['cheques']), 2)
			self.assertEqual(len(result['data_preview']['fund_clusters']), 1)
			self.assertEqual(result['counts'].get('cheques'), 2)
			self.assertEqual(result['format'], 'sql')
		finally:
			sql_path.unlink(missing_ok=True)

	def test_sql_dump_parser_ignores_unknown_tables(self):
		from admin_panel.views import _sql_dump_to_serialized
		text = "INSERT INTO `django_migrations` (`id`, `app`, `name`) VALUES (1, 'auth', 'initial');"
		self.assertEqual(_sql_dump_to_serialized(text), [])


class CashierPermissionsTests(TestCase):
	def setUp(self):
		self.cashier_user = User.objects.create_user(username='cashier_test', email='cashier_test@example.com', password='pass12345')
		from cashier.models import Profile
		Profile.objects.get_or_create(user=self.cashier_user, defaults={'role': 'cashier'})
		self.client.force_login(self.cashier_user)

	def test_cashier_can_add_supplier(self):
		response = self.client.post(reverse('suppliers'), {
			'action': 'create',
			'account_name': 'New Supplier Ltd',
			'amount': '150.00',
			'status': 'active'
		}, follow=True)
		self.assertEqual(response.status_code, 200)
		self.assertIn("added", str(response.context.get('success', '') or ''))
		from cashier.models import Supplier
		self.assertTrue(Supplier.objects.filter(account_name='New Supplier Ltd').exists())

	def test_cashier_can_edit_own_supplier(self):
		from cashier.models import Supplier
		sup = Supplier.objects.create(account_name='Old Name', created_by=self.cashier_user)
		response = self.client.post(reverse('suppliers'), {
			'action': 'edit',
			'sup_id': sup.pk,
			'account_name': 'Updated Name',
			'amount': '250.00',
			'status': 'active'
		}, follow=True)
		self.assertEqual(response.status_code, 200)
		self.assertIn("updated", str(response.context.get('success', '') or ''))
		sup.refresh_from_db()
		self.assertEqual(sup.account_name, 'Updated Name')

	def test_cashier_can_edit_own_cheque(self):
		from cashier.models import Cheque, Supplier
		sup = Supplier.objects.create(account_name='Payee', created_by=self.cashier_user)
		cheque = Cheque.objects.create(cheque_number='999999', payee=sup, amount=Decimal('100.00'), created_by=self.cashier_user, status='draft')
		response = self.client.post(reverse('cheque_edit', args=[cheque.pk]), {
			'cheque_number': '111111',
			'amount': '200.00',
			'payee_id': sup.pk,
			'date': '2026-08-04'
		})
		self.assertEqual(response.status_code, 302) # Redirects on success
		cheque.refresh_from_db()
		self.assertEqual(cheque.cheque_number, '111111')

	def test_cashier_can_delete_own_cheque(self):
		from cashier.models import Cheque, Supplier
		sup = Supplier.objects.create(account_name='Payee', created_by=self.cashier_user)
		cheque = Cheque.objects.create(cheque_number='999999', payee=sup, amount=Decimal('100.00'), created_by=self.cashier_user, status='draft')
		response = self.client.post(reverse('cheque_delete', args=[cheque.pk]))
		self.assertEqual(response.status_code, 302)
		from cashier.models import Cheque
		self.assertFalse(Cheque.objects.filter(pk=cheque.pk).exists())
